# Metrics Dictionary (Starter)

- **value_sales**: Total sales value (e.g., INR) for the period.
- **unit_sales**: Total units sold for the period.
- **share**: Brand’s value share (%) within its category/market/channel for the period.
- **value_yoy**: (value_sales / value_sales_12m_ago) - 1
- **share_yoy**: share - share_12m_ago
